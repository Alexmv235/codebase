import javax.swing.*;

public class form {
    private JComboBox ipSelector;
    private JTextPane chatField;
    private JTextField textField1;
    private JButton sendButton;
    private JPanel TopBar;
    private JPanel ChatArea;
    private JPanel BottomBar;


}
